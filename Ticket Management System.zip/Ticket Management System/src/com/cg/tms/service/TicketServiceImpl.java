/**
 * 
 */
package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;

/**
 * @author agupt166
 *
 */
public class TicketServiceImpl implements TicketService {

	/* (non-Javadoc)
	 * @see com.cg.tms.service.TicketService#raiseNewTicket(com.cg.tms.dto.TicketBean)
	 */
	
	TicketDAO dao = new TicketDAOImpl();
	@Override
	
	
	public boolean raiseNewTicket(TicketBean ticketBean) {
		// TODO Auto-generated method stub
		return dao.raiseNewTicket(ticketBean);
	}

	/* (non-Javadoc)
	 * @see com.cg.tms.service.TicketService#listTicketCategory()
	 */
	@Override
	public List<String> listTicketCategory() {
		// TODO Auto-generated method stub
		return dao.listTicketCategory();
	}

}
