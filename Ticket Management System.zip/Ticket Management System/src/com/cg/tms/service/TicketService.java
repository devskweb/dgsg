/**
 * 
 */
package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dto.TicketBean;

/**
 * @author agupt166
 *
 */
public interface TicketService {
	boolean raiseNewTicket(TicketBean ticketBean);
	List<String> listTicketCategory();
}
