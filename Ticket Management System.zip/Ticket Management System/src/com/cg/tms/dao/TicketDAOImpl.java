/**
 * 
 */
package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.util.Util;

/**
 * @author agupt166
 *
 */
public class TicketDAOImpl implements TicketDAO {

	/* (non-Javadoc)
	 * @see com.cg.tms.dao.TicketDAO#raiseNewTicket(com.cg.tms.dto.TicketBean)
	 */
	
	HashMap<String,TicketBean> TicketLog = new HashMap<String,TicketBean>();
	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		// TODO Auto-generated method stub
		if(!TicketLog.containsKey(ticketBean.getTicketNo()))
			return false;
		else
			TicketLog.put(ticketBean.getTicketNo(), ticketBean);
		return true;
	}

	/* (non-Javadoc)
	 * @see com.cg.tms.dao.TicketDAO#listTicketCategory()
	 */
	@Override
	public List<String> listTicketCategory() {
		// TODO Auto-generated method stub
		 Map<String,String> map = Util.getTicketCategoryEntries();
		 List<String> list = new ArrayList<>(map.values());
		 return list;
	}

}
