/**
 * 
 */
package com.cg.tms.ui;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;
import com.cg.tms.util.Util;

/**
 * @author agupt166
 *
 */
public class MainUI {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TicketService service = new TicketServiceImpl();
		System.out.println("Welcome to ITIMD Help Desk");
		while(true) {
			String categoryName;
			String ticketCategoryId;
			List<String> list = service.listTicketCategory();
			System.out.println("1.Raise a ticket");
			System.out.println("2.Exit from the system");
			Scanner s = new Scanner(System.in);
			System.out.println("Enter choice");
			int c = s.nextInt();
			if(c==1) {
				System.out.println("Select Ticket Category from below list");
				System.out.println("1." + list.get(0));
				System.out.println("2." + list.get(1));
				System.out.println("3." + list.get(2));
			}
			System.out.println("");
			System.out.println("Enter option");
			int category = s.nextInt();
			if(category==1) {
				ticketCategoryId="tc001";
			}
			else if(category==2) {
				ticketCategoryId="tc002";
			}
			else {
				ticketCategoryId="tc003";
			}
			System.out.println("Enetr description related to issue");
			System.out.println("(here you need to type the details)");
			String ticketDescription = s.next();
			
			System.out.println("Enter Priority");
			System.out.println("1.low 2.medium 3.high");
			int ticketPriority = s.nextInt();
			
			int r = (int) Math.random();
			int ticketNo = (r*200)+1000+c+category+ticketPriority;
			String  ticketStatus = "New";
			String itimdComments="Raise new ticket";
			service.raiseNewTicket(new TicketBean(ticketNo, ticketCategoryId, ticketDescription, ticketPriority, ticketStatus, itimdComments));
			
		}

	}

}
